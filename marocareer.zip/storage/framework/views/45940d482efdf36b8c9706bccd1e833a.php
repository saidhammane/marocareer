<!-- Fonts -->
<link rel="preconnect" href="https://fonts.bunny.net">
<link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />
<link rel="icon" type="image/x-icon" href="<?php echo e(asset('img/logo_32_32.png')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('css/linearicons.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/magnific-popup.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/nice-select.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/nice-select.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/owl.carousel.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/sweetalert2.min.css')); ?>">
<?php /**PATH S:\projescts\marocareer\resources\views/partials/header.blade.php ENDPATH**/ ?>