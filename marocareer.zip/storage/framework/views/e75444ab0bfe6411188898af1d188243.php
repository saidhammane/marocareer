

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section class="banner-area relative" id="home">
        <div class="overlay overlay-bg"></div>
        <div class="container">
            <div class="row fullscreen d-flex align-items-center justify-content-center">
                <div class="banner-content col-lg-12">
                    <?php if(isset($jobDataJson)): ?>
                        <?php $jobData = json_decode($jobDataJson, true); ?>
                        <?php if(count($jobData) > 0): ?>
                            <img src="<?php echo e($jobData[0]['imageCallCenter']); ?>" class="img-thumbnail" alt="<?php echo e($callCenter); ?>" title="callCenter" loading="lazy">
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>

    <!-- Start post Area -->
    <section class="post-area section-gap">
        <div class="container">
            <div class="row justify-content-center d-flex">
                <div class="col-lg-8 post-list">
                    <?php if(isset($jobDataJson)): ?>
                        <?php $jobData = json_decode($jobDataJson, true); ?>
                        <?php $__currentLoopData = $jobData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="single-post d-flex flex-row">
                                <div class="thumb" style="padding: 24px;">
                                    <img src="<?php echo e($job['jobImgLink']); ?>" alt="<?php echo e($job['jobTitle']); ?>"
                                        title="<?php echo e($job['jobTitle']); ?>" loading="lazy" height="100" width="100"
                                        style="border-radius:15px;">
                                </div>
                                <div class="job-container">
                                    <div class="details">
                                        <div class="title ">
                                            <?php
                                                $urlSegments = explode('/', parse_url($job['jobUrl'], PHP_URL_PATH));
                                                $lastSegmentUrl = end($urlSegments);
                                            ?>
                                            <div class="titles">
                                                <a href="/application/<?php echo e($lastSegmentUrl); ?>">
                                                    <h4><?php echo e($job['jobTitle']); ?></h4>
                                                </a>
                                                <h6><?php echo e($job['metaData']); ?></h6>
                                            </div>
                                            <ul class="btns">
                                                <li><a href="/application/<?php echo e($lastSegmentUrl); ?>">Postuler</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
    <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH S:\projescts\marocareer\resources\views/callCenterZone/jobs.blade.php ENDPATH**/ ?>