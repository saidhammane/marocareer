<?php $__env->startSection('content'); ?>
    <div class="container">
        
        <table class="table table-striped">
            <thead>
                <tr>
                    
                    <th scope="col">Email</th>
                    <th scope="col">Date Created</th>
                    <th scope="col">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $dataEmailSubscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <tr id="row-<?php echo e($item->id); ?>">
                        
                        <td><?php echo e($item->email); ?></td>
                        <td><?php echo e($item->created_at); ?></td>
                        <td><button data-id="<?php echo e($item->id); ?>" class="btn btn-danger delete-button">Delete</button></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    
    
    <script>
        
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH S:\projescts\marocareer\resources\views/home.blade.php ENDPATH**/ ?>