<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Form Submission</title>
</head>
<body>
    <h1>New Contact Form Submission</h1>
    
    <p><strong>Name:</strong> <?php echo e($mailData['name']); ?></p>
    <p><strong>Email:</strong> <?php echo e($mailData['email']); ?></p>
    <p><strong>Subject:</strong> <?php echo e($mailData['object']); ?></p>
    
    <p><strong>Message:</strong></p>
    <p><?php echo e($mailData['message']); ?></p>
    
    <p>Thank you for using our contact form.</p>
</body>
</html>
<?php /**PATH S:\projescts\marocareer\resources\views/mail/sendMail.blade.php ENDPATH**/ ?>