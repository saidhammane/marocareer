<section class="banner-area relative" id="home">
    <div class="overlay overlay-bg"></div>
    <div class="container">
        <div class="row fullscreen d-flex align-items-center justify-content-center">
            <div class="banner-content col-lg-12">
                <?php switch($type):
                    case ('jobApply'): ?>
                        <?php if(isset($jobDataJson)): ?>
                            <?php $jobDataTypes = json_decode($jobDataJson, true); ?>
                            <?php $__currentLoopData = $jobDataTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <h1 class="text-white"><?php echo e($job['titleJob']); ?></h1> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        <?php break; ?>
                    <?php case ('home'): ?>
                        <h1 class="text-white">Votre carrière est notre priorité</h1>
                        <p class="text-white">Le choix numéro un pour les emplois en centre d'appels au Maroc.</p>
                        <?php break; ?>
                    <?php default: ?>
                        <?php if($city == "typeCity"): ?> <h1 class="text-white">Emplois de type <?php echo e($type); ?></h1>
                        <?php else: ?> <h1 class="text-white">Emplois à <?php echo e($city); ?> <?php if($type != null): ?> - <?php echo e($type); ?> <?php endif; ?> </h1>
                        <?php endif; ?>
                <?php endswitch; ?>
                <form class="serach-form-area">
                    <div class="row justify-content-center form-wrap">
                        <div class="col-lg-5 form-cols">
                            <div class="default-select" id="default-selects2">
                                <select id="cities">
                                    <option>Toutes les villes</option>
                                    <?php if(isset($jobDataJsonCity)): ?>
                                        <?php $jobDataCities = json_decode($jobDataJsonCity, true); ?>
                                        <?php $__currentLoopData = $jobDataCities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($job['jobCity'] == 'Ville'): ?>
                                                <?php continue; ?>
                                            <?php endif; ?>
                                            <option value="<?php echo e($job['jobCity']); ?>"><?php echo e($job['jobCity']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>

                        <div class="col-lg-5 form-cols">
                            <div class="default-select" id="default-selects2">
                                <select id="type">
                                    <option>Type</option>
                                    <?php if(isset($jobDataJsonType)): ?>
                                        <?php $jobDataTypes = json_decode($jobDataJsonType, true); ?>
                                        <?php $__currentLoopData = $jobDataTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($job['jobType'] == 'Type'): ?>
                                                <?php continue; ?>
                                            <?php endif; ?>
                                            <option value="<?php echo e($job['jobType']); ?>"><?php echo e($job['jobType']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>

                        <div class="col-lg-2 form-cols">
                            <button type="button" class="btn btn-info" id="searchBtnHome">
                                <span class="lnr lnr-magnifier"></span> Rechercher
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section><?php /**PATH S:\projescts\marocareer\resources\views/partials/filter.blade.php ENDPATH**/ ?>