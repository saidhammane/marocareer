

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <section class="banner-area relative" id="home">
        <div class="overlay overlay-bg"></div>
        <div class="container">
            <div class="row fullscreen d-flex align-items-center justify-content-center">
                <div class="banner-content col-lg-12">
                    <h1 class="text-white">Liste des centres d'appels - Maroc</h1>
                    <form class="serach-form-area">
                        <div class="row justify-content-center form-wrap">
                            <div class="col-lg-8 form-cols">
                                <div class="default-select" id="default-selects2">
                                    <select id="citiesCallCnter">
                                        <option>Villes</option>
                                        <?php if(isset($jobDataJsonCity)): ?>
                                            <?php $jobDataCities = json_decode($jobDataJsonCity, true); ?>
                                            <?php $__currentLoopData = $jobDataCities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($job['jobCity'] == 'Ville'): ?>
                                                    <?php continue; ?>
                                                <?php endif; ?>
                                                <option value="<?php echo e($job['jobCity']); ?>"><?php echo e($job['jobCity']); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-2 form-cols">
                                <button type="button" class="btn btn-info" id="searchBtnCallCnter">
                                    <span class="lnr lnr-magnifier"></span> Rechercher
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <section>
        <div class="container mt-20 mb-20">
            <div class="row">
                <?php if(isset($callCenterDataJson)): ?>
                    <?php $callCenterData = json_decode($callCenterDataJson, true); ?>
                    <?php $__currentLoopData = $callCenterData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 mt-20 reletiveCol">
                            <div class="card ">
                                <img class="card-img-top darkened-image" src="<?php echo e($job['ImgLink']); ?>"
                                    alt="<?php echo e($job['name']); ?>" title="<?php echo e($job['name']); ?>" height="150" loading="lazy">
                                <a href="/callcenters/<?php echo e(basename($job['url'])); ?>">
                                    <img class="overlay-image rounded" src="<?php echo e($job['ImgLink']); ?>" alt="<?php echo e($job['name']); ?>"
                                        title="<?php echo e($job['name']); ?>" height="80" loading="lazy" width="80"></a>
                                <div class="card-body">
                                    <div style="text-align: center;">
                                        <div class="card-title h5"><?php echo e($job['name']); ?></div>
                                    </div>
                                    <p class="card-text"><?php echo e($job['description']); ?></p>
                                    <div style="text-align: center;">
                                        <?php
                                            $urlSegments = explode('/', parse_url($job['url'], PHP_URL_PATH));
                                            $lastSegmentUrl = end($urlSegments);
                                        ?>
                                        <a href="/callcenters/<?php echo e($lastSegmentUrl); ?>/offres-emploi" class="btn btn-secondary"><?php echo e($job['offres']); ?></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH S:\projescts\marocareer\resources\views/callCenter/callcenters.blade.php ENDPATH**/ ?>