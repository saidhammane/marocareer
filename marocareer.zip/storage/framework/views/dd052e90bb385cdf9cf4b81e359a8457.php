

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- start banner Area -->
    <section class="banner-area relative" id="home">
        <div class="overlay overlay-bg"></div>
        <div class="container">
            <div class="row d-flex align-items-center justify-content-center">
                <div class="about-content col-lg-12">
                    <h1 class="text-white">
                        Quiz
                    </h1>
                    <p class="text-white"><a href="/">Accueill </a> <span class="lnr lnr-arrow-right"></span> <a
                            href="/quiz"> Quiz </a></p>
                </div>
            </div>
        </div>
    </section>
    <section class="post-area section-gap">
        <div class="container">
            <div class="row justify-content-center d-flex">
                <div class="col-lg-8 post-list">
                    <div class="row">
                        <?php if(isset($quizDataJson)): ?>
                            <?php $quizData = json_decode($quizDataJson, true); ?>
                            <?php $__currentLoopData = $quizData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-6 mt-20 reletiveCol">
                                    <div class="card ">
                                        <a href="url" target="_blank">
                                            <img class="card-img-top darkened-image" src="<?php echo e(asset('img/backquiz.webp')); ?>"
                                                alt="name" title="name" height="180" loading="lazy">
                                            <img class="overlay-image rounded" src="<?php echo e($job['imgUrl']); ?>" alt="name"
                                                title="name" height="120" loading="lazy" width="120"></a>
                                        <div class="card-body">
                                            <div style="text-align: center;">
                                                <div class="card-title h5"><?php echo e($job['title']); ?></div>
                                            </div>
                                            <br>
                                            <div style="text-align: center;">
                                                <p class="card-text"><?php echo e($job['qd']); ?>

                                                    <br>Nombre de participants: <span
                                                        style="font-weight: bold"><?php echo e($job['NombreParticipants']); ?></span>
                                                    <br>Note moyenne : <span
                                                        style="font-weight: bold"><?php echo e($job['NoteMoyenne']); ?></span>
                                                </p>
                                            </div>
                                            <br>
                                            <div style="text-align: center; width: 100%;">
                                                <a style="width: 100%;" href="<?php echo e($job['url']); ?>" class="btn btn-secondary"
                                                    target="_blank">Lancer le test</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-lg-4 sidebar">
                    <div class="single-slidebar">
                        <h4>Les centres qui recrutent
                        </h4>
                        <div class="row">
                            <?php if(isset($callCenterRecrutJson)): ?>
                                <?php $callCenterRecrut = json_decode($callCenterRecrutJson, true); ?>
                                <?php $__currentLoopData = $callCenterRecrut; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-4 mt-10">
                                        <a href="callcenters/<?php echo e($job['title']); ?>">
                                            <img src="<?php echo e($job['imgUrl']); ?>" class="img-thumbnail" alt="<?php echo e($job['title']); ?>"
                                                title="<?php echo e($job['title']); ?>" loading="lazy" height="200" width="200">
                                        </a>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="single-slidebar">
                        <a href="https://www.moncallcenter.ma/guide/reussir-cv/" target="_blank">
                            <img src="https://www.moncallcenter.ma/images/reussir-votre-cv.png" class="img-thumbnail"
                                alt="Réussir votre CV" title="Réussir votre CV">
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End banner Area -->
    <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH S:\projescts\marocareer\resources\views/callCenter/quiz.blade.php ENDPATH**/ ?>