

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section class="banner-area relative" id="home">
        <div class="overlay overlay-bg"></div>
        <div class="container">
            <div class="row fullscreen d-flex align-items-center justify-content-center">
                <div class="banner-content col-lg-12">
                    <?php if(isset($jobDataJson)): ?>
                        <?php $jobData = json_decode($jobDataJson, true); ?>
                        <?php $__currentLoopData = $jobData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <img src="<?php echo e($job['imageCallCenter']); ?>" class="img-thumbnail" alt="Responsive image"
                                style="border-radius: 10px">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </section>

    <!-- Start post Area -->
    <section class="post-area section-gap">
        <div class="container">
            <div class="row justify-content-center d-flex">
                <div class="col-lg-4 post-list">
                    <div class="single-post d-flex flex-row"
                        style="box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2); border-radius: 10px;">
                        <div class="thumb">
                            <div class="cardsTitle">Présentation:</div>
                            <hr class="new5"><br><br>
                            <?php if(isset($jobDataJson)): ?>
                                <?php $jobData = json_decode($jobDataJson, true); ?>
                                <?php $__currentLoopData = $jobData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <p><?php echo e($job['presentationJob']); ?></p>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 post-list">
                    <div class="single-post d-flex flex-row">
                        <div class="thumb">
                            <div class="cardsTitle">Avantages:</div>
                            <hr class="new5"><br><br>
                            <?php if(isset($jobDataJson)): ?>
                                <?php $jobData = json_decode($jobDataJson, true); ?>
                                <?php $__currentLoopData = $jobData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <p><?php echo e($job['avantagesJob']); ?></p>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 post-list">
                    <div class="single-post d-flex flex-row">
                        <div class="thumb">
                            <div class="cardsTitle">Nos offres d'emploi:</div>
                            <hr class="new5"><br><br>


                            <?php if(isset($jobDataJson)): ?>
                                <?php $jobData = json_decode($jobDataJson, true); ?>
                                <?php $__currentLoopData = $jobData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="<?php echo e($job['nosOffresEemploiUrlJob']); ?>" target="_blank">
                                        <p class="titleJobCallcenter"><?php echo e($job['nosOffresEemploiTitreJob']); ?></p>
                                    </a>
                                    <p><?php echo e($job['nosOffresEemploiDescJob']); ?></p>
                                    <hr class="new6">
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End post Area -->

    <div class="container mb-5">
        <a href="https://www.moncallcenter.ma/<?php echo e($callCenter); ?>" target="_blank" class="btn btn-primary text-white h4"
            style="width: 100%">Voir plus</a>
    </div>

    <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH S:\projescts\marocareer\resources\views/callCenterZone/home.blade.php ENDPATH**/ ?>