

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section class="banner-area relative" id="home">
        <div class="overlay overlay-bg"></div>
        <div class="container">
            <div class="row fullscreen d-flex align-items-center justify-content-center">
                <div class="banner-content col-lg-12">
                    <?php if(isset($quizDataJson)): ?>
                        <?php $quizData = json_decode($quizDataJson, true); ?>
                        <?php if(count($quizData) > 0): ?>
                            <img src="<?php echo e($quizData[0]['imgUrl']); ?>" class="img-thumbnail" alt="<?php echo e($title); ?>"
                                title="<?php echo e($title); ?>" loading="lazy">
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>

    <section class="post-area section-gap">
        <div class="container">
            <div class="row justify-content-center d-flex">
                <div class="col-lg-1 post-list">
                    <div class="single-post d-flex flex-row"
                        style="box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2); border-radius: 10px;">
                        <div class="thumb">
                            <img src="<?php echo e(asset('img/quiz.png')); ?>" alt="<?php echo e($title); ?>" title="<?php echo e($title); ?>"
                                loading="lazy" height="20" width="20">

                        </div>
                    </div>
                </div>
                <div class="col-lg-10 post-list">
                    <div class="single-post d-flex flex-row"
                        style="box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2); border-radius: 10px;">
                        <div class="thumb">
                            <span class="cardsTitle" style="text-align: center;"><?php echo e($title); ?></span>

                        </div>
                    </div>
                </div>
                <div class="col-lg-1 post-list">
                    <div class="single-post d-flex flex-row"
                        style="box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2); border-radius: 10px;">
                        <div class="thumb">
                            <img src="<?php echo e(asset('img/quiz.png')); ?>" alt="<?php echo e($title); ?>" title="<?php echo e($title); ?>"
                                loading="lazy" height="20" width="20">

                        </div>
                    </div>
                </div>


                <?php if(isset($quizDataJson)): ?>
                    <?php $quizData = json_decode($quizDataJson, true); ?>
                    <div class="col-lg-3 post-list">
                        <div class="single-post d-flex flex-row"
                            style="box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2); border-radius: 10px;">
                            <div class="thumb">
                                <div class="cardsTitleQuiz">Durée :</div>
                                <hr class="new5"><br><br>
                                <?php $__currentLoopData = $quizData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="cardsTitle" style="text-align: center;"><?php echo e($quiz['quizDuree']); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 post-list">
                        <div class="single-post d-flex flex-row"
                            style="box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2); border-radius: 10px;">
                            <div class="thumb">
                                <div class="cardsTitleQuiz">Nombre de questions:</div>
                                <hr class="new5"><br><br>
                                <?php $__currentLoopData = $quizData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="cardsTitle"
                                        style="text-align: center;"><?php echo e($quiz['quizNombreQuestions']); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 post-list">
                        <div class="single-post d-flex flex-row"
                            style="box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2); border-radius: 10px;">
                            <div class="thumb">
                                <div class="cardsTitleQuiz">Nombre de participants:</div>
                                <hr class="new5"><br><br>
                                <?php $__currentLoopData = $quizData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="cardsTitle"
                                        style="text-align: center;"><?php echo e($quiz['quizNombreParticipants']); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 post-list">
                        <div class="single-post d-flex flex-row"
                            style="box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2); border-radius: 10px;">
                            <div class="thumb">
                                <div class="cardsTitleQuiz">Note moyenne:</div>
                                <hr class="new5"><br><br>
                                <?php $__currentLoopData = $quizData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="cardsTitle"
                                        style="text-align: center;"><?php echo e($quiz['quizNoteMoyenne']); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12 post-list">
                        <div class="single-post d-flex flex-row"
                            style="box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2); border-radius: 10px;">
                            <div class="thumb">
                                <div class="cardsTitle">Description :</div>
                                <hr class="new5"><br><br>
                                <?php $__currentLoopData = $quizData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="cardsTitleQuiz"
                                        style="text-align: center;"><?php echo e($quiz['quizDescription']); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                <div class="col-lg-12">
                    <a href="https://www.moncallcenter.ma/test/<?php echo e($url); ?>" class="btn btn-primary h5" target="_blank"
                        style="width: 100%; color:white;">Lancer le test</a>
                </div>
            </div>
        </div>
    </section>


    <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH S:\projescts\marocareer\resources\views/quiz/home.blade.php ENDPATH**/ ?>