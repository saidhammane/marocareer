

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.filter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



    <style>
        .btn-primary {
            display: flex;
            justify-content: center;
            align-items: center;
        }
    </style>

    <section class="post-area section-gap">
        <div class="container">
            <div class="row justify-content-center d-flex">
                <div class="col-lg-12 post-list">
                    <?php if(isset($jobDataJson)): ?>
                        <?php $jobData = json_decode($jobDataJson, true); ?>
                        <?php $__currentLoopData = $jobData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="single-post d-flex flex-row">
                                <div class="thumb" style="padding: 24px;">
                                    <a href="<?php echo e($job['callcenterNameJobUrl']); ?>">
                                        <img src="<?php echo e($job['callcenterImgJob']); ?>" alt="<?php echo e($job['titleJob']); ?>"
                                            title="<?php echo e($job['titleJob']); ?>" loading="lazy" height="100" width="100"
                                            style="border-radius:15px;">
                                    </a>

                                </div>
                                <div class="job-container">
                                    <div class="details">
                                        <div class="title ">
                                            <div class="titles">
                                                <a href="https://www.moncallcenter.ma//offre-emploi/<?php echo e($lastSegment); ?>"
                                                    target="_blank">
                                                    <h3><?php echo e($job['titleJob']); ?></h3>
                                                </a>
                                                <br>
                                                <h4>Centre d'appels : <span class="h5"><?php echo e($job['callcenterNameJob']); ?></span></h4>
                                                <h6><?php echo e($job['metaDataJob']); ?></h6>
                                                <h6><?php echo e($job['languageJob']); ?> </h6>
                                            </div>
                                            <ul class="btns" style="padding-left: 50%">
                                                <li><a href="https://www.moncallcenter.ma//offre-emploi/<?php echo e($lastSegment); ?>"
                                                        target="_blank">Postuler</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
    <section class="post-area section-gap">
        <div class="container">
            <div class="row justify-content-center d-flex">
                <div class="col-lg-12 post-list">
                    <?php if(isset($jobDataJson)): ?>
                        <?php $jobData = json_decode($jobDataJson, true); ?>
                        <?php $__currentLoopData = $jobData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="single-post d-flex flex-row">
                                <div class="thumb" style="padding: 24px;">
                                    <div class="h3"> <img src="<?php echo e(asset('img/description.png')); ?>"
                                            alt="icon de description du poste rechercher " width="40" height="40">
                                        &nbsp;&nbsp;Descriptif du poste: </div>
                                    <br>
                                    <p class="fs-4"><?php echo nl2br(e($job['descriptifPosteJob'])); ?></p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
    <section class="post-area section-gap">
        <div class="container">
            <div class="row justify-content-center d-flex">
                <div class="col-lg-12 post-list">
                    <?php if(isset($jobDataJson)): ?>
                        <?php $jobData = json_decode($jobDataJson, true); ?>
                        <?php $__currentLoopData = $jobData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="single-post d-flex flex-row">
                                <div class="thumb" style="padding: 24px;">
                                    <div class="h3"> <img src="<?php echo e(asset('img/magnifying-glass.png')); ?>"
                                            alt="icon de profil Recherché " width="40" height="40">&nbsp;&nbsp;Profil
                                        Recherché: </div>
                                    <br>
                                    <p class="fs-4"><?php echo nl2br(e($job['profilRechercheJob'])); ?></p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>

    <div class="container mb-5">
        <div class="container">
            <div class="container">
                <div class="container">
                    <a href="https://www.moncallcenter.ma//offre-emploi/<?php echo e($lastSegment); ?>" target="_blank"
                        class="btn btn-primary text-white h4">Postuler</a>
                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH S:\projescts\marocareer\resources\views/callCenter/jobsApply.blade.php ENDPATH**/ ?>